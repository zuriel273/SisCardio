package org.codehaus.groovy.ant

org.codehaus.groovy.ant.GroovyTest.FLAG = "from groovy file called from ant"
