package org.codehaus.groovy.tools.groovydoc.testfiles;

public interface JavaInterfaceWithMultipleInterfaces extends GroovyInterface1, JavaInterface1, Runnable {
}
