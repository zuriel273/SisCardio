package org.codehaus.groovy.tools.groovydoc.testfiles;

public interface JavaInterface1 {
}
