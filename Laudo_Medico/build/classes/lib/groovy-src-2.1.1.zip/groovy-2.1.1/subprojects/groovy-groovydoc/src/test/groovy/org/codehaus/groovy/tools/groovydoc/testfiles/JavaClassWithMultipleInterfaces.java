package org.codehaus.groovy.tools.groovydoc.testfiles;

public abstract class JavaClassWithMultipleInterfaces implements GroovyInterface1, JavaInterface1, Runnable {
}
